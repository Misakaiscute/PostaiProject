$(document).ready(function () {
    $('#countyDropdown').change(function () {
        var selectedCountyId = $(this).val();
        $.ajax({
            url: 'fetch_cities.php',
            type: 'POST',
            data: { selectedCountyId: selectedCountyId },
            success: function (response) {
                $('#cityDropdown').html(response);
                $('#postalCode').val('');
            }
        });
    });

});